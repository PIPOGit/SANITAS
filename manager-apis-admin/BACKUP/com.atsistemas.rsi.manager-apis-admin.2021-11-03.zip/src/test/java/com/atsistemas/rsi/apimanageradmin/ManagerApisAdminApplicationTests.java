package com.atsistemas.rsi.apimanageradmin;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ManagerApisAdminApplicationTests {

	@Test
	void contextLoads() {
	}

}
